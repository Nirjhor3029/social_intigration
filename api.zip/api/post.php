<?php
/**
 * Created by PhpStorm.
 * User: Nirjhor
 * Date: 10/29/2018
 * Time: 1:47 PM
 */
if(isset($_POST['submit'])){
    $url = $_POST['url'];
    $post = $_POST['post'];

    echo "$url <br> $post";
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="container">
        <h2>Facebook post</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="email">Url:</label>
                <input type="text" class="form-control" id="" placeholder="Enter Url" name="url">
            </div>
            <div class="form-group">
                <label for="pwd">Post:</label>
                <textarea  class="form-control" id="" placeholder="Enter Facebook Post" name="post"></textarea>
            </div>

            <button type="submit" class="btn btn-primary" name="submit">Post on Facebook</button>
        </form>
    </div>
</div>

</body>
</html>
