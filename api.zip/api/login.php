<?php
/**
 * Created by PhpStorm.
 * User: Nirjhor
 * Date: 10/29/2018
 * Time: 12:52 PM
 */
?>
<?php
session_start();
require 'Facebook/autoload.php';

$fb = new Facebook\Facebook([
    'app_id' => '1522119087932263', // Replace {app-id} with your app id
    'app_secret' => 'dab5006761762d95f465818c2a94bdd4',
    'default_graph_version' => 'v3.2',
]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // Optional permissions
$loginUrl = $helper->getLoginUrl('http://localhost/testphp/api/callback.php', $permissions);

//echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';
header('location:' .$loginUrl);
?>

